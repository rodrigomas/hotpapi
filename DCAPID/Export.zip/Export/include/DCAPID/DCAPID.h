//
//  DCAPID.h
//  DCAPID
//
//  Created by Rodrigo Marques on 11/11/13.
//  Copyright (c) 2013 Ande Tecnologia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "AuthResponse.h"
#import "CardInfo.h"
#import "Notification.h"
#import "Transaction.h"
#import "QRCodeResp.h"
#import "TokenResp.h"
#import "DCAPIException.h"
#import "ProtocolKeys.h"

@interface DCAPID : NSObject

@property (nonatomic, retain) NSString *_serverAdress;
@property (nonatomic, retain) NSNumber *_comunicationTimeout;

- (void)setup: (NSString*) serverAdress withTimeout: (int) comunicationTimeout;
- (BOOL)registerUser: (NSString*) name withCPF: (NSString*) cpf withRG: (NSString*) rg withBirth: (NSDate*) birthDate withEmail: (NSString*) email;
- (BOOL)recoverPassword: (NSString*) name withCPF: (NSString*) cpf withBith: (NSDate*) birthDate withEmail: (NSString*) email;
- (BOOL)changePassword: (NSString*) email withOldPassword: (NSString*) oldPassword withNewPassword: (NSString*) newPassword;
- (NSString*)retrieveEmail: (NSString*) name withCPF: (NSString*) cpf withBith: (NSDate*) birthDate;
- (AuthResponse*)registerPhone: (NSString*) email withPassword: (NSString*) password withIMEI: (NSString*) imei;
- (NSMutableArray*) receiveCards: (NSString*) secret withGUID: (NSString*) guid;
- (NSMutableArray*) receiveNotifications: (NSString*) secret withGUID: (NSString*) guid;
- (NSMutableArray*) receiveTransactions: (NSString*) secret withGUID: (NSString*) guid withCNT: (int) cnt withLastGUID: (NSString*) lastGuid;
- (BOOL) sendEvaluation: (NSString*) transactionGuid withRate: (int) rate withMessage: (NSString*) message withGUID: (NSString*) guid withKEY: (NSString*) secretKey;
- (QRCodeResp*) createQRCode: (NSString*) secretKey withGUID: (NSString*) guid withLatitute: (float) latitute withLongitute: (float) longitude withCard: (NSString*) cardNumber withIMEI: (NSString*) imei withWith: (int) width withHeight: (int) height;
- (TokenResp*) createToken: (NSString*) secretkey withGUID: (NSString*) guid;

+ (DCAPID*) getInstance;

@end
